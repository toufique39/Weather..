API_KEY = "YOUR_GEMINI_API_KEY"
MODEL = "gemini-1.5-flash"
