from google import genai
from config import API_KEY, MODEL
from tools.weather_tool import get_weather

client = genai.Client(api_key=API_KEY)

def run_weather_agent(query):
    query_lower = query.lower()

    if "weather" in query_lower or "temperature" in query_lower:
        city = "Dhaka"
        report = get_weather(city)
        return f"Here is the weather update:\n{report}"

    response = client.models.generate_content(
        model=MODEL,
        content=query
    )
    return response.text
