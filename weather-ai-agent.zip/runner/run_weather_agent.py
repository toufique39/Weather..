from agent.weather_agent import run_weather_agent

print("🌦 Weather AI Agent is ready!")
print("--------------------------------------------")

while True:
    user_input = input("You: ")
    reply = run_weather_agent(user_input)
    print(f"Agent: {reply}")
