import requests

def get_weather(city):
    url = (
        "https://api.open-meteo.com/v1/forecast?"
        "latitude=23.8103&longitude=90.4125&hourly=temperature_2m"
    )
    response = requests.get(url)
    data = response.json()
    temp = data["hourly"]["temperature_2m"][0]
    return f"Weather in {city}: {temp}°C"
